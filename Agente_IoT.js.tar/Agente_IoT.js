var sys =  require('sys'),
	http = require('http'),
	url = require('url');
;

// var operations =  {
//  add: function(a,b){ return a + b}
// }

http.createServer(function(req, res){
	//var parts = req.url.split("/"),	
var q = url.parse(req.url, true).query;
  var txt = q.valorsensor + " " + q.temperatura;

// op = parts[1],
// op2 =parts[2],
// a = parseInt(parts[3], 4),
// b = parseFloat(parts[4], 4);
//c = parseFloat(parts[5], 4),
//d = parseFloat(parts[6], 4),
//e = parseFloat(parts[7], 4),
//f = parseFloat(parts[8], 4),
//g = parseFloat(parts[9], 4),
//h = parseFloat(parts[10], 4);

 //var result = op;
 	res.writeHead(200, {'Context-type':'text/html'});
 	res.write("<h1> </h1>" )
 	res.write("<br />")

 	res.end("" + txt);

// 	sys.puts(sys.inspect(parts));

// var result = op ? op(a,b) : "Error";
// res.writeHead(200, {'Context-type':'text/html'});
// res.write("<h1>"Funcionando" </h1>" );
// res.write("<br />");

// res.end("");

var mqtt = require('mqtt')
var client  = mqtt.connect('mqtt://200.129.39.91')

console.log('inicio');
client.on('connect', function () {
client.subscribe('/admin/47fb/attrs');

setInterval(function()              {
	
	}, 90000);
//setInterval(function()              {
	
  client.publish("/admin/47fb/attrs", '{"valorsensor":'+ q.valorsensor +'}');
  //client.publish("/admin/47fb/attrs", '{"umidade":'+ leitura_dht11[1] +'}');
  client.publish("/admin/47fb/attrs", '{"temperatura":'+ q.temperatura +'}');
 //}, 1000);
})
//setInterval(function()              {
//	}, 1000);
client.on('message', function (topic, message) {  
  console.log("msg recebida => " + message.toString());  
})


}).listen(3000, "200.129.39.91");

sys.puts("Server rodando");
